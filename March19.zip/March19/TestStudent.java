package com.corejava;

public class TestStudent {

	public static void main(String[] args) {
		
		System.out.println(Student.a2.country);
		
		System.out.println(Student.schoolName);
		Student.getSchoolName();
		
		
		Address a1 = new Address();
		a1.flatNo = 420;
		a1.area = "BTM";
		a1.city="Bangalore";
		
		Student s = new Student();
		s.name = "Ramu";
		s.std=6;
		s.a=a1;
		
		System.out.println(s.getStudentDetails());
		
		System.out.println();
		
		Student.a2.getAddressDetails();
		
	}

}
