package com.corejava;

public class Address {
	
	int flatNo;
	String area;
	String city;
	static String country = "India";
	
	public String getAddressDetails()
	{
		return (flatNo+area+city);
	}
	
	public static void getCountry()
	{
		System.out.println("you are a proud citigen of the country "+country);
	}
	


}
