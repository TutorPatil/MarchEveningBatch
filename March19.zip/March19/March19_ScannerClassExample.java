package com.corejava;

import java.util.Scanner;

public class March19_ScannerClassExample {

	public static void main(String[] args) {
	
		//March19_ScannerClassExample sc = new March19_ScannerClassExample();
		//sc.findFactorial(5);
		
		//System.out.println("Please enter the number  for which factorial needs to be found!!\n");
		
		//Scanner src = new Scanner(System.in);
		//int num = src.nextInt();
			
		
		//findFactorial(num);
		
		System.out.println("Please enter the String for which you want to find the lenght");
		Scanner src = new Scanner(System.in);
		String s = src.nextLine();
	
		
		System.out.println(s.length());
		
	}
	
	public static void findFactorial(int num)
	{
		int fact = 1;
		
		while ( num > 1)
		{
			fact = (fact * num);
			num--;
		}
		
		System.out.println(fact);
	}

}
