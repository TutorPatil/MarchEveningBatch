package com.corejava;

public class Student {
	
	String name;
	int std;
	
	Address a;	
	
	static String  schoolName = "govt primary school MG Road";
	
	static Address a2; 
	
	public String getStudentDetails()
	{
		//System.out.println(a2.getAddressDetails());
		return (name+"--"+std+a.getAddressDetails());
		
		
	}
	
	public static void getSchoolName()
	{
		System.out.println("student is from "+schoolName);
	}
	

}
