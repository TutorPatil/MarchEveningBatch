package com.sale;

public interface Pet extends Prani,SuperAnimal{
	
	public static final int legs = 4;
	boolean nonVegEating = true;
	
	public abstract void recognizeOwner();	
	void makNoiseWhenHungry();
	
	
	public static void giveShakeHand()
	{
		System.out.println("The Pet can give shake Hand");
	}
	

}
