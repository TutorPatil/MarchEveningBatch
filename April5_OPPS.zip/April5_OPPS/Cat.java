package com.sale;
 
public class Cat extends Animal implements Pet {
	
	static int legs = 10;
	

	public Cat(int age) {
		super(age);		
	}
	
	public void huntRat()
	{
		System.out.println("The cat of the age "+age +
				" of the name "+ name + " is hunting the Rat....");
	}
	
	public void eat()
	{
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is eating....");
		
	}

	public void sleep() {
		
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is sleeping.......");
		
	}

	public void recognizeOwner() {
		System.out.println(" The cat blinks its eys when the owner comes and licks owners legs...");
		System.out.println(legs);
		
	}

	
	public void makNoiseWhenHungry() {
		System.out.println("The Cat makes noise and moves its tails rapidly when its hungry...");
		
	}
	

	public void showMagicalProperties() {
		System.out.println("The Cat is showing its magical powers ");
		
	}

	
	public void takesBirth() {
		System.out.println("The cat is also a prani...");
		
	}


}
