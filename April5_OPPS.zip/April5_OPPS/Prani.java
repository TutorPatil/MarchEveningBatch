package com.sale;

public interface Prani {
	
	
	void takesBirth();

}
