package com.sale;



public class TestDog {

	public static void main(String[] args) {
	
		Dog d = new Dog(5, 25);
		
		
		d.eat();
		d.makNoiseWhenHungry();
		d.recognizeOwner();		
		System.out.println(Pet.legs);
		d.followCommands();
		
		Pet.giveShakeHand();
		Dog.dance();
		Animal.dance();
		
		System.out.println("======================");
		
		Cat c = new Cat(5);
		
		c.eat();
		c.makNoiseWhenHungry();
		c.recognizeOwner();
		
		System.out.println(Cat.legs);
		System.out.println(Pet.legs);
	}

}
