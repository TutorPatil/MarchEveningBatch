package com.sale;

public interface SuperAnimal {
	
	public abstract void showMagicalProperties();	
	
	void takesBirth();

}
