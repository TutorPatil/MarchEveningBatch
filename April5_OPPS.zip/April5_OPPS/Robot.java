package com.sale;

public interface Robot {
	
	public static final String material = "SteelAndPlastic";
	
	
	public abstract void followCommands();
	

}
