package com.sale;

public abstract class Animal {
	
	int age;
	String name;
	
	public Animal(int age)
	{
		//System.out.println(" Inside the animal class  constructor....");
		this.age = age;
		this.name = "Prani";
	}
	
	public void eat()
	{
		System.out.println("The animal of the age "+age +" of the name "
				+ name +" is eating....");
	}
	
	public void drink()
	{
		System.out.println("The animal of the age "+age +" of the name "
				+ name +" is drink....");
	}
	
	public abstract void sleep();
	
	public static void dance()
	{
		System.out.println("The animal is dancing....");
	}

}
