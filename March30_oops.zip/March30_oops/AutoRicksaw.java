package com.corejava.oops;

public class AutoRicksaw  extends Vehicle{
	
	public void startByPullingHandle()
	{
		System.out.println(" The auto of the colour "+colour +" is been started ....");
	}
	
	
	

}
