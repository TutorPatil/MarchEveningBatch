package com.corejava.oops;

public class TestCar {

	public static void main(String[] args) {

		Car c= new Car();
		
		c.colour = "White";
		c.cost = 1000000;
		c.noOfWheels=4;
		
		c.drive();
		
		c.fillAir();
		
		c.driveReverse();
		
		
		System.out.println("===========================");
		
		AutoRicksaw auto1 = new AutoRicksaw();
		auto1.colour = "Black";
		auto1.cost = 200000;
		auto1.noOfWheels = 3;
		
		auto1.drive();
		auto1.fillAir();
		auto1.startByPullingHandle();
	}

}
