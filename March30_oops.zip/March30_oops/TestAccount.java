package com.corejava.oops;

public class TestAccount {

	public static void main(String[] args) {
	
		BankAccount ba = new BankAccount();
		
		ba.setName("Ramu");
		ba.setMobile(878787878);
		ba.setSeniorCitizen(false);
		
		ba.withDrawAmount(5000);
		
		System.out.println(ba.getBalance());
		
		
		ba.depositAmount(15000);
		
		ba.withDrawAmount(5000);
		
		
		System.out.println(ba.getBalance());
		
		
		
	}

}
