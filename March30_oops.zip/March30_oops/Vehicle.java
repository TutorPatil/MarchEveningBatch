package com.corejava.oops;

public class Vehicle {

	String colour;
	int noOfWheels;
	int cost;
	int seatingCapacity;
	
	public void drive()
	{
		System.out.println(" The vehicle of the colour "
	          +colour +" of the category  "+noOfWheels + " is been driven");
		
	}
	
	public void fillAir()
	{
		System.out.println("The vehicle of the color"+colour+" filled with air");
		
	}
	
	
	
}
