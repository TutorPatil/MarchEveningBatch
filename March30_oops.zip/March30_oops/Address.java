package com.corejava.oops;

public class Address {
	
	int flatNo;
	String area;
	String city;
	
	public Address(int flatNo, String area, String city) {
	
		this.flatNo = flatNo;
		this.area = area;
		this.city = city;
	}
	
	

}
