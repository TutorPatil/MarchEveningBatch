package com.corejava.oops;

public class Car extends Vehicle{
	
	public void driveReverse()
	{
		System.out.println(" The car of the colour "+colour +" is been driven in the reverse direction");
		
	}

}
