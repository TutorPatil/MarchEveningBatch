package com.corejava.collections;

public class Dog {
	
	String name;
	
	
	public void eat()
	{
		System.out.println("The dog iseating..");
		
	}

}
