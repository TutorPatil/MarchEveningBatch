package com.oops.poly1;

public class TestAnimal {

	public static void main(String[] args) {
	
			Object a = new Dog();	
		
		
//			a.eat();
//			a.drink();
//			a.dance();
			
			//Dog d = (Dog)a;
			//d.bark();
			
			((Dog)a).bark();
			
			((Dog)a).eat();
			
			Object[] x = {100,12,15,1,48};
			
			Object[] s = {"java","Bhava","Mava"};
			
			Object[][] s2 = new String[3][3];
			
			
			
			
		
	}

}
