package com.oops.poly1;

public class Cat implements Animal{
	

	public void eat() {
		System.out.println("The Cat is eating");
	}

	
	public void drink() {
		
		System.out.println("The Cat is drinking..");
	}

	
	public void dance() {
		
		System.out.println("The Cat is dancing...");
	}

}
