package com.oops.poly1;

public class Dog implements Animal {

	
	public void eat() {
		System.out.println("The dog is eating");
	}

	
	public void drink() {
		
		System.out.println("The dog is drinking..");
	}

	
	public void dance() {
		
		System.out.println("The dog is dancing...");
	}
	

	public void bark() {
		
		System.out.println("The dog is barking...");
	}

}
