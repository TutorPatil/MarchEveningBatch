package com.oops.poly;

public class TestAnimal {

	public static void main(String[] args) {
	
		String type = "Dog";
		Animal a = null;
				
	if(type.equals("Cat"))
	
	{
		 a = new Cat();
		 a.age = 5;
		 a.name = "Bill";
	}	
	
	if(type.equals("Dog"))		
	{
		 a = new Dog();
		 a.age = 5;
		 a.name = "Kutta";
	}
		
		a.eat();
		a.drink();
	
		
		if (a instanceof Cat)
			((Cat)a).huntRat();		
		
		if (a instanceof Dog)
			((Dog)a).bark();
		
		a.makeAnimalDance(a);
		
		Animal d = Animal.getObject();
	}

}
