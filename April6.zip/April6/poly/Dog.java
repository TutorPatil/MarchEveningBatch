package com.oops.poly;

public class Dog extends Animal {
	

	public void eat()
	{
		System.out.println("The Dog of the age "+age +" of the name "
				+ name +" is eating....");
	}
	

	public void bark()
	{
		System.out.println("The Dog of the age "+age +" of the name "
				+ name +" is Barking bow bow.......");
	}

	
	public void dance() {
		System.out.println(" The dog is dancing.....");
		
	}
}
