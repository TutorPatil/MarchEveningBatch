package com.oops.poly;

public abstract class Animal {
	
	int age;
	String name;
	
	
	public void eat()
	{
		System.out.println("The animal of the age "+age +" of the name "
				+ name +" is eating....");
	}
	
	public void drink()
	{
		System.out.println("The animal of the age "+age +" of the name "
				+ name +" is drink....");
	}
	
	public abstract void dance();
	
	public void makeAnimalDance(Object a)
	{
		((Dog)a).dance();
	}
	
	public static Animal getObject()
	{
		Animal d = new Cat();
		return d;
	}
	


}
