package com.oops.poly;

public class Cat extends Animal{
	
	public void eat()
	{
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is eating....");
	}
	
	
	public void huntRat()
	{
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is good in hunting the Rats......");
	}


	public void dance() {
		System.out.println(" The Cat is dancing.....");
		
	}

}
