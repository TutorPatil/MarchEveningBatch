package com.corejava.oops;

public class TestCustoomException {

	public static void main(String[] args)  {
	
		Student s = new Student();
		s.name = "Ramu";
		s.age= 23;
		
		try {
			s.printStudentAge();
		} catch (InvalidAgeException e) {			
			e.printStackTrace();
		}		
		System.out.println("XXXXXXXXXXXXX");
	}

}
