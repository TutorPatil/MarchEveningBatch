package com.corejava.oops;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class April13_Exceptions {

	public static void main(String[] args) throws IOException {
//	
//		try {
//			finallyExample3();
//		} catch (IOException e) {			
//			e.printStackTrace();
//		}finally
//		{
//			System.out.println("Inside the finally block...");
//		}
		
		//finallyExample3();
		//System.out.println("after calling the method...");

	}
	
	public static void finallyExample1()
	{
		int x = 10;
		int y=1;
		int z=0;
		
		try {
			z= x/y;
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}finally
		{
			System.out.println("The value of z is "+z);
		}
		System.out.println("After the try catch finally.....");
	}
	
	public static void finallyExample2() 
	{
		File f = new File("D:\\sample.txt");
		FileWriter fw = null;
		try {
			fw = new FileWriter(f);
			fw.write("Welcome to Java");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally {
			try {
				fw.flush();
				fw.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
			
		}
		System.out.println("After the try catch finally.....");
	}
	
	
	public static void finallyExample3() throws IOException 
	{
		File f = new File("X:\\sample123.txt");
		f.createNewFile();
		FileWriter fw = new FileWriter(f);
		
		fw.write("Welcome to Java");
		fw.flush();
		fw.close();
					
		}		
	
	public static void exceptionHandlingex2()
	{
		try {
			System.out.println("Inside the try block...");
		}finally {
			System.out.println("Inside the finally block....");
		}
		System.out.println("XXXXXXXXXXXXXXXXX");
	}
	
//	public static void exceptionHandlingex2()
//	{
//		finally (Exception e) {
//			System.out.println("Inside the try block...");
//		} 
//		System.out.println("XXXXXXXXXXXXXXXXX");
//	}
}

	


