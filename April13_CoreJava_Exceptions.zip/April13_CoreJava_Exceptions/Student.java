package com.corejava.oops;

public class Student {
	int age;
	String name;
	
	public void printStudentAge() throws InvalidAgeException 
	{
		if( (age > 0) && (age <15))
		{
			System.out.println("This student is eligible for exams");
		}else
		{
			//InvalidAgeException ie = new InvalidAgeException("The student is not eligible as his age is not in the limits");
			//throw ie;
			throw new InvalidAgeException("The student is not eligible as his age is not in the limits");
			
		}
	}

}
