package com.corejava.collections;

public class Outer {
	
	int outerAge = 10;
	
	public void testOuter()
	{
		System.out.println("Inside the test Outer Method");
		Inner in = new Inner();
		System.out.println(in.innerAge);		
	}
	
	
	class Inner {
		
		int innerAge = 8;
		
		public void testInner()
		{
			System.out.println("Inside the test Inner Method");
			System.out.println(outerAge);
		}		
		
	}
	
	private class InnerPrivate{
		
		int privateAge = 5;
		
		public void testPrivateInnerClass()
		{
			System.out.println("Inside the testPrivateInnerClass Method");
			System.out.println(outerAge);			
			
		}	
		
	}
	
	static class StaticInner{
		
		int staticAge = 3;
		
		public static void testStaticInnerClass()
		{
			System.out.println("Inside the testStaticInnerClass Method");
			//System.out.println(outerAge);			
		}
		
	}
	
	

}
