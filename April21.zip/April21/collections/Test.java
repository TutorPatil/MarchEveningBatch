package com.corejava.collections;

import java.util.Comparator;

public class Test implements Comparator<Mobile>{

	
	public int compare(Mobile o1, Mobile o2) {
		if (o1.cost > o2.cost)		
			return 1;
		else if(o1.cost < o2.cost)
			return -1;
		else
			return 0;	
	}
	
	

}
