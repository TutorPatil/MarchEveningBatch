package com.corejava.collections;

import java.util.*;



public class April16_Collections {

	public static void main(String[] args) {
		
		
		List<String> al2 = new ArrayList<String>();
		
		al2.add("selenium");
		al2.add("java");
		al2.add("Mava");
		
		
		List<Dog> dList = new ArrayList<Dog>();
		
		
		
	}
	
	//arrayListEx1();
	public static void arrayListEx1()
	{
		Dog d = new Dog();
		
		
		List al = new ArrayList();
		
		al.add("selenium");
		al.add(25);
		al.add(d);
		al.add(25);
		al.add(null);
		
		System.out.println(al);
		System.out.println(al.size());
		
		//System.out.println(al.contains(d));
		
		System.out.println(al.contains(d));
		
		System.out.println(al.isEmpty());
		
		al.remove(d);
		
		
		System.out.println(al.contains(d));
		
		System.out.println(al);
		
		System.out.println(al.get(1));
		
		System.out.println(al.size());
		for(int x=0; x<al.size();x++)
		{
			System.out.println(al.get(x));
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	public static void arraysExHetro()
	{

		String s = "selenium";
		
		Object s1 = "selenium";
		
		Dog d = new Dog();
		
		Dog d1 = new Dog();
		
		Dog d2 = new Dog();
		
		Dog[] dArray = {d,d1,d2};
		
		Object[] objArray = {d,d1,s,s1,"java"};
		
		System.out.println(Arrays.toString(dArray));
		
	}

}
