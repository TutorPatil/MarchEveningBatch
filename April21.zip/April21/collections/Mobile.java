package com.corejava.collections;

import java.util.Comparator;

//public class Mobile implements Comparable<Mobile>{
public class Mobile {
	
	int memory;
	String brand;
	double cost;
	String colour;	
	public Mobile(int memory, String brand, double cost, String colour) {
		super();
		this.memory = memory;
		this.brand = brand;
		this.cost = cost;
		this.colour = colour;
	}
	public String toString()
	{
		return colour+" "+brand+" "+memory+" "+cost;
	}
	
	
	
	/*
	public int compareTo(Mobile o) {
		
		if (this.cost > o.cost)		
			return 1;
		else if(this.cost < o.cost)
			return -1;
		else
			return 0;		
		
	}
*/
}
