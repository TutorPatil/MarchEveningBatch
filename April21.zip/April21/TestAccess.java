package com.sales;

import com.sale.Dog;

public class TestAccess extends Dog{

	public TestAccess(int age, int pAge) {
		super(age, pAge);		
	}

	public static void main(String[] args) {
		System.out.println(Dog.colour);

	}

}
