package com.sale;

public class Dog extends Animal implements Pet,Robot{
	
	int age;
	protected static String colour = "Black";
	
	
	public Dog(int age, int pAge)
	{
		super(pAge);
		//super.age = pAge;
		this.age = age;
		
	}
	
	public void eat()
	{
		System.out.println("The Dog of the age "+age +" of the name "
				+ name +" is eating....");
		//System.out.println(age);
		//System.out.println("Parents age is "+super.age);
		//System.out.println("==============");
		//super.eat();
		System.out.println(colour);
	}
	
	public void bark()
	{
		
		System.out.println("The dog of the age "+age +" of the name "
				+ name +" is Barking bow bow.......");
	}


	public void sleep() {
		
		System.out.println("The dog of the age "+age +" of the name "
				+ name +" is sleeping.......");
	}
	
	
	 public  int hashCode1()
	 {
		 return this.age;
	 }
	
	 
	 public boolean equals(Object obj) {
		 
		 	Dog d1 = (Dog)obj;
		 	
		 	if( this.age == d1.age)
		 		return true;
		 	else
		 		return false;
		 		
	    }
	 
	 
	 public String toString() {
	        return this.name +"  "+this.age;
	    }

	
	public void recognizeOwner() {
		System.out.println(" The dog is able to recognize its owner and moves  its tail..");
		
	}

	
	public void makNoiseWhenHungry() {
		System.out.println("The dog barks when its hungry....");
		
	}

	
	public void followCommands() {
		System.out.println(" you  should follow your owners commands...");
		
	}

	
	public void showMagicalProperties() {
		System.out.println("The DOg is showing its magical powers ");
		
	}
	
	public static void dance()
	{
		System.out.println("The Dog is dancing....");
	}


	public void takesBirth() {
		System.out.println("The dog is a Prani hence  it takes birth....");
		
	}
	

}
