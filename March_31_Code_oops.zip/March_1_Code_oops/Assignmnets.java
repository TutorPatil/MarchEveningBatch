package com.corejava.oops;

import java.util.Scanner;

public class Assignmnets {

	public static void main(String[] args) {
	
		scannerClassEx();

	}
	
	public static void scannerClassEx()
	{
		
		System.out.println("Please enter your name");
		
		Scanner src = new Scanner(System.in);
		String name = src.nextLine();		
		System.out.println(name);
		
		System.out.println("Please enter your surname");
		String surName = src.nextLine();
		
		System.out.println(" Your name is "+name+"Your Surname is "+surName);
		
		
		/*
		System.out.println("Please enter your age");
		Scanner src = new Scanner(System.in);
		int age = src.nextInt();
		System.out.println(" Your age is "+age);
		
		System.out.println("Please enter your name");
		
		Scanner src1 = new Scanner(System.in);
		String name = src1.nextLine();
		
		System.out.println("You name is  "+name);
		*/
		
		
	}
	
	public static void bigSmallOf2Arrays()
	{
		
		int[] x = {1,2,11,15,12,198,55,44};
		int[] y = {3,5,16,18,100,291,77,66,33,22,9};
		
		
		int i = 0;
		int big = 0;
		int small = x[0];
		
		while(i<x.length || i < y.length)
		{
			if( i < x.length)
			{
				if(x[i] > big)
				   big = x[i];
				if(x[i]< small)
				   small = x[i];
			}
			
			if( i < y.length)
			{
				if(y[i] > big)
				   big = y[i];
				if(y[i]< small)
				   small = y[i];
			}
			i++;
			
			
			}
		
		System.out.println("The biggest ts "+big);
		System.out.println("The smallest is  "+small);
		}
	
	}


