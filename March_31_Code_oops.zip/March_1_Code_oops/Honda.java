package com.corejava.oops;

public class Honda extends Car{
	
	public void getHondaInsurance()
	{
		System.out.println("The car of the colour "+colour +" Is been insured....");
	}

	
	public void closeDoor() {
		System.out.println("This is the close door method implementation in HOnda CLass");
		
	}


}
