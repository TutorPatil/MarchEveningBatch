package com.corejava.oops;

public class BankAccount {
	
	private int balance = 10000;
	private int mobile;
	private String name ;
	boolean isSeniorCitizen ;
	
	
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isSeniorCitizen() {
		return isSeniorCitizen;
	}
	public void setSeniorCitizen(boolean isSeniorCitizen) {
		this.isSeniorCitizen = isSeniorCitizen;
	}
	public int getBalance() {
		return balance;
	}
	
	
	public void withDrawAmount( int amt)
	{
		if( amt < balance)
		{
			System.out.println(" Thanks for visiting please collect your cash...");
			updateBalanceOnWithDraw(amt);
		}
		else
		{
			System.out.println(" You dont have sufficient balance....");
		}
		
	}
	
	private void updateBalanceOnWithDraw(int amt)
	{
		balance = balance - amt;
	}
	
	
	public void depositAmount(int amt)
	{
		System.out.println(" Your amount is been deposited..Thanks.....");
		updateBalanceOnDeposit(amt);
	}
	
	
	private void updateBalanceOnDeposit(int amt)
	{
		balance = balance + amt;
	}
	
	
	

}
