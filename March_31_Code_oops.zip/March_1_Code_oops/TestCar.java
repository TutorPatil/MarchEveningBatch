package com.corejava.oops;

import java.util.Arrays;

public class TestCar {

	public static void main(String[] args) {
		
	Maruti WagonR = new Maruti();
	WagonR.colour = "Black";
	WagonR.cost = 500000;
	WagonR.noOfWheels = 4;
	WagonR.seatingCapacity = 5;
	WagonR.brand = "Maruti";
	WagonR.model="WagonR";
	WagonR.setPin(1234);
	
	
	
	WagonR.drive();
	WagonR.fillAir();
	WagonR.driveReverse();
	WagonR.getMarutiInsurance();
	WagonR.closeDoor();
	
	
	System.out.println("=================");
	
	Maruti celerio = new Maruti();
	celerio.colour="Gray";
	celerio.cost = 600000;
	celerio.noOfWheels = 4;
	celerio.seatingCapacity = 5;
	celerio.brand = "Maruti";
	celerio.model = "Celerio";
	
	
	celerio.drive();
	celerio.fillAir();
	celerio.driveReverse();
	celerio.closeDoor();
	
	
	System.out.println("=================");
	
	Honda hCar = new Honda();
	
	
	hCar.colour="Blue";
	hCar.cost = 800000;
	hCar.noOfWheels = 4;
	hCar.seatingCapacity = 5;
	hCar.brand = "Honda";
	hCar.model = "City";
	
	hCar.drive();
	hCar.fillAir();
	hCar.driveReverse();
	hCar.closeDoor();
	
	}

}
