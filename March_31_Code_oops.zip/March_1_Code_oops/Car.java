package com.corejava.oops;

public abstract class Car extends Vehicle{
	String brand ;
	String model;
	
	public void driveReverse()
	{
		System.out.println(" The car of the colour "+colour +" of the brand "+brand +" of the model "+model +"is been driven in the reverse direction");
		System.out.println(colour);
		//System.out.println(pin);
		
	}
	
	public void fillAir()
	{
		System.out.println("The vehicle of the color"+colour+" is been filled with Notrogen Air");
		
	}

	
	public void fillAir(int x)
	{
		System.out.println("The vehicle of the color"+colour+" is been filled with Notrogen Air");
		
	}
}
