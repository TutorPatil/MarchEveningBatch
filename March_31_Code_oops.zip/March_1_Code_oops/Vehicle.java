package com.corejava.oops;

public abstract  class Vehicle {

	String colour;
	int noOfWheels;
	int cost;
	int seatingCapacity;
	private int pin;
	
	
	
	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public void drive()
	{
		System.out.println(" The vehicle of the colour "
	          +colour +" of the category  "+noOfWheels + " is been driven" +"The pin  is "+pin);
		
	}
	
	public  void fillAir()
	{
		System.out.println("The vehicle of the color"+colour+" filled with air");
		
	}
	
	public abstract void closeDoor();
	
	
	
	
}
