package com.corejava.oops;

public class Maruti extends Car{
	
	public void getMarutiInsurance()
	{
		System.out.println("The car of the colour "+colour +" Is been insured....");
	}
	
	public void fillAir()
	{
		System.out.println("This is the overridden fillAir  method from Maruti Class");
		
	}

	
	public void closeDoor() {
		System.out.println("This is the implementation for CloseDoor Method..from Maruti Class");
		
	}

}
