package com.corejava.oops;

public class Dog extends Memal {
	
	String name ;
	
	
	public Dog(String name) {		
		this.name = name;
	}

	public Dog(String name,String mName,String aName)
	{
		super(mName,aName);
		this.name = name;
		
	}
	
	public void bark()
	{
		System.out.println(name);
		System.out.println(super.name);
		System.out.println("The dog is barking...");
	}

	public void sleep() {
		System.out.println("The Dog is sleeping....");
		
	}
	
	public void walk()
	{
		System.out.println("The DOg of the name "+ name +" is walking..");
	}
	
	public void eat()
	{
		super.walk();
		System.out.println(" The Dog of the name "+ name + "of the age  "+age +"is eating...");
	}

}
