package com.corejava.oops;

public abstract class Memal extends Animal {
	String name;
	
	public Memal()
	{
		System.out.println("Constructor of Memal Class...");
	}
	
	public Memal(String name,String aName)
	{
		super(aName);
		System.out.println(aName);
		this.name = name;
		
	}
	
	
	public void walk()
	{
		System.out.println("The memal of the name "+ name +" is walking..");
	}

	
	

}
