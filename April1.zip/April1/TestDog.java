package com.corejava.oops;

public class TestDog {

	public static void main(String[] args) {
	
		
		Dog d = new Dog("Kutta", "Memaal", "Prani");
		
		
		
		d.age = 4;
		
		d.eat();
		d.drink123();
		d.walk();
		d.bark();
		
		d.sleep();
		
		

	}

}
