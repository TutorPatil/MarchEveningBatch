package com.corejava.oops;

public abstract class Animal {
	
	String name = "prani";
	int  age;
	
	
	public Animal()
	{
		System.out.println("Constructor of Animal Class...");
	}
	

	public Animal(String name)
	{
		System.out.println(name);
		this.name = name;
		
	}
	
	public  void eat()
	{
		System.out.println(" The animal of the name "+name +"is eating...");
	}
	
	public void drink123()
	{
		System.out.println(" The animal...... of the name "+ name + "is drinking......");
	}
	
	public abstract void sleep();
	

}
