package com.sale;

public class Cat extends Animal {
	

	public Cat(int age) {
		super(age);		
	}
	
	public void huntRat()
	{
		System.out.println("The cat of the age "+age +
				" of the name "+ name + " is hunting the Rat....");
	}
	
	public void eat()
	{
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is eating....");
		
	}

	public void sleep() {
		
		System.out.println("The Cat of the age "+age +" of the name "
				+ name +" is sleeping.......");
		
	}

}
