package com.sale;



public class TestDog {

	public static void main(String[] args) {
	
		Dog d = new Dog(5, 25);
		Dog d1 = new Dog(6, 28);
		
		d.name = "kutta";
		
		d.eat();
		d.drink();
		d.bark();
		d.sleep();	
						
		System.out.println(d.getClass());	
		System.out.println(d.hashCode());
		System.out.println(d1.hashCode());
		System.out.println(d.equals(d1));
		
		System.out.println(d.toString());
		System.out.println(d);
		
		
		System.out.println("========================");
		
		Cat c = new Cat(4);
		c.name = "Billi";
		
		c.eat();
		c.drink();
		c.huntRat();
		c.sleep();
		System.out.println(c.getClass());
		System.out.println(c.hashCode());
		
		System.out.println(c.toString());
		System.out.println(c);
		
	}

}
