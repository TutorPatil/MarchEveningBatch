package com.sale;

public class Dog extends Animal{
	
	int age;
	
	
	public Dog(int age, int pAge)
	{
		super(pAge);
		//super.age = pAge;
		this.age = age;
		
	}
	
	public void eat()
	{
		System.out.println("The Dog of the age "+age +" of the name "
				+ name +" is eating....");
		System.out.println(age);
		System.out.println("Parents age is "+super.age);
		System.out.println("==============");
		super.eat();
	}
	
	public void bark()
	{
		
		System.out.println("The dog of the age "+age +" of the name "
				+ name +" is Barking bow bow.......");
	}


	public void sleep() {
		
		System.out.println("The dog of the age "+age +" of the name "
				+ name +" is sleeping.......");
	}
	
	
	 public  int hashCode1()
	 {
		 return this.age;
	 }
	
	 
	 public boolean equals(Object obj) {
		 
		 	Dog d1 = (Dog)obj;
		 	
		 	if( this.age == d1.age)
		 		return true;
		 	else
		 		return false;
		 		
	    }
	 
	 
	 public String toString() {
	        return this.name +"  "+this.age;
	    }

	

}
