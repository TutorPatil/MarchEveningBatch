package com.corejava.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TestComparable {

	public static void main(String[] args) {
		
		
		Mobile m1 = new Mobile(2, "RedMi", 8000.50, "Black");
		Mobile m2 = new Mobile(3, "Samsung", 12000.80, "White");
		Mobile m3 = new Mobile(4, "OnePlus",28000.50, "Gray");
		Mobile m4 = new Mobile(5, "Apple", 38000.20, "white");
		
		
		//System.out.println(m1.compareTo(m2));
		
		
		
		ArrayList<Mobile> mList = new ArrayList<Mobile>();
		
		mList.add(m4);
		mList.add(m1);
		mList.add(m2);
		mList.add(m3);
		
		System.out.println(mList);
		
		//Collections.sort(mList);
		
		//Comparator<Mobile> c = new Test();
		//Collections.sort(mList,c);
		
		
		Collections.sort(mList, new Comparator<Mobile>() {

			
			public int compare(Mobile o1, Mobile o2) {
				if (o1.cost > o2.cost)		
					return 1;
				else if(o1.cost < o2.cost)
					return -1;
				else
					return 0;	
			}
			
			
		});
		
		
		System.out.println(mList);

	}

}
