package com.corejava.collections;

import java.util.Comparator;

public class Test {

	public static void main(String[] args) {
		
		/*
		Outer out = new Outer();
		
		System.out.println(out.outerAge);
		out.testOuter();
		
		// Creating the object of the inner class using outer class reference
		Outer.Inner oin = 	out.new Inner();
		System.out.println(oin.innerAge);
		oin.testInner();
		
		// Creating the Object of the inner static class
		Outer.StaticInner inStatic = new Outer.StaticInner();
		
		// We cant create the object of inner private class
		 
		 */
		
		String s = "selenium";
		s.toUpperCase().length();
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://google.com");
		driver.manage();
		driver.closeBrowser();
		
		driver.manage().maximize();
		
	}
	

}
