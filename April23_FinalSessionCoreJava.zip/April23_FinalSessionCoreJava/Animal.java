package com.corejava.collections;


// Functional Interfaces...
public interface Animal {
	
	void eat();	

}
