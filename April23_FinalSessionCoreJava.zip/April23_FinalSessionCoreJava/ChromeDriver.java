package com.corejava.collections;

public class ChromeDriver implements WebDriver, WebDriver.Window,WebDriver.TimeOuts{

	
	public void get(String url) {
		System.out.println("Navigating to url "+url);
		
	}


	public void closeBrowser() {
		System.out.println("Closing the browser...");
		
	}

	
	public WebDriver.Window manage() {
		System.out.println("Inside the manage method...");
		return null;
		
	}


	
	public void maximize() {
	System.out.println("Maximizing the window.....");
		
	}


	
	public void implicitlyWait(int timeInSecs) {
		System.out.println("Setting the time out as "+timeInSecs);
		
	}

}
