package com.corejava.collections;

public class Tester {
	
	
	public static void main(String[] args) {
	
		/*
	FunctionalIntFace fi = new FunctionalIntFace() {		
		
		public int addNumbers(int x, int y) {			
			return (x+y);
		}	
	};
	
	System.out.println(fi.addNumbers(10, 20));
	*/
		FunctionalIntFace fi =  (x,y) -> (x+y);	
		
		System.out.println(fi.addNumbers(10, 20));
		
	}
	
	
	
	
	
	

	/*
	// Functional Programming....
	public static void main(String[] args) {
	
		Animal a = new Animal() {
			
			public void eat() {
				System.out.println("Cat is eating..");
				
			}
		};
		a.eat();

	
	
	}
*/
	
	
	
	
}
