package com.corejava.collections;

import java.util.ArrayList;
import java.util.Collections;

public class April21_ComparableComareTo {

	public static void main(String[] args) {
		
		
		String s = "Selenium";
		
		ArrayList<String> al = new ArrayList<String>();
		
		al.add("selenium");
		al.add("java");
		al.add("automation");
		al.add("testing");
		
		System.out.println(al);
		
		Collections.sort(al);
		
		System.out.println(al);
		
		
	}

}
