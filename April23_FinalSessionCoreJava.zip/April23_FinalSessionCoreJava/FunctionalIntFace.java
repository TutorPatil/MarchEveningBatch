package com.corejava.collections;


@FunctionalInterface
public interface FunctionalIntFace {
	
	int addNumbers(int x, int y);

}
