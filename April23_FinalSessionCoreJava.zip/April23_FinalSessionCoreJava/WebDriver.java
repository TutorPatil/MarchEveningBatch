package com.corejava.collections;

public interface WebDriver {
	
	void get(String url);
	
	void closeBrowser();
	
	Window manage();
	
	
	interface Window{
		
		void maximize();
		
	}
	
	static interface TimeOuts{
		
		void implicitlyWait(int timeInSecs);
		
	}
	

}
